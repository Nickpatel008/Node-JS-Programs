const users = [
    {
        username : "user1",
        password : "pass1",
        name : "josh",
        age : 20,
    },
    {
        username : "user2",
        password : "pass2",
        name : "alice",
        age : 22,
    },
    {
        username : "user3",
        password : "pass3",
        name : "joe",
        age : 32,
    },
    {
        username : "user4",
        password : "pass4",
        name : "jack",
        age : 23,
    },
    {
        username : "user5",
        password : "pass5",
        name : "alan",
        age : 19,
    },
    {
        username : "user6",
        password : "pass6",
        name : "alan",
        age : 29,
    },
    {
        username : "user7",
        password : "pass7",
        name : "alan",
        age : 35,
    },
    {
        username : "user8",
        password : "pass8",
        name : "braine",
        age : 22,
    },
    {
        username : "user9",
        password : "pass9",
        name : "jade",
        age : 30,
    },
    
];

module.exports = users;