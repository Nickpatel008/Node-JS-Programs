const express = require('express');
const app = express();
app.use(express.json);
const port = 5050;

const users = require("./users");

app.get("/" , (req , res) => { res.send("Hello") });

app.post("/registration" , (req , res) => {

    const uname = req.body.username;
    const pass = req.body.password;
    const name = req.body.name;
    const age = req.body.age;

    const user = users.filter((u) => u.username === uname);

    if(user.length === 0)
    {
        return res.json({ data : "Registration Successfull..." });    
    }
    else
    {
        return res.json({ data : "Username already taken! choose another..." });    
    }

});


app.listen(port, () => console.log(`Server running on port 5050`));

app.post("/login" , (req , res) => {
    
    const uname = req.body.username;
    const pass = req.body.password;

    const user = users.filter((u) => u.username === uname && u.password === pass);

    if(user.length === 0)
    {
        return res.json({ data : "User not exist" });    
    }
    else
    {
        return res.json({ data : "Log in successfull..." });    
    }

});

// http://localhost:5000/list/?name=alan&age=25

app.get("/list" , (req , res) => { 
    
    const name = req.query.name;
    const age = req.query.age;

    let userList = users.filter( u => u.name === name && u.age > parseInt(age));

    if(userList.length === 0)
    {
        return res.json({ data : "User not found" });    
    }
    else
    {
        return res.json({ data : userList });    
    }

 });