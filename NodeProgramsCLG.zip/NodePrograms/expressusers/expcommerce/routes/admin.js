const express = require('express');
const router = express.Router();
router.use(express.json());

router.get("/admin" , (req, res) => {
    res.json({ data: "Welcome Admin..." })
});

module.exports = router;