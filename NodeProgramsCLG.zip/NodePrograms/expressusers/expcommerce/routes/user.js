const express = require('express');
const router = express.Router();
router.use(express.json());

router.get("/registration" , (req, res) => {
    res.json({ data: "User registration successfull..." })
});

router.get("/login" , (req, res) => {
    res.json({ data: "User login successfull..." })
});

router.get("/forgotpassword" , (req, res) => {
    res.json({ data: "User forgot password page..." })
});

module.exports = router;
