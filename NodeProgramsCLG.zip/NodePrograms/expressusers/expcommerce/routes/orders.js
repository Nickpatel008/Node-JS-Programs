const express = require('express');
const router = express.Router();
router.use(express.json());

router.get("/phones" , (req, res) => {
    res.json({ data: ["iPhone 13" , "One Plus 9R" , "Samsung S20 FE"] })
});

module.exports = router;