/*
    epxcommerce using Express Router

    4 parts -> user , admin , order , product

    main file   > app.js
    Make folder > routes
    routes      > user.js
    routes      > admin.js
    routes      > orders.js
    routes      > products.js
*/

const express = require('express');
const app = express();
app.use(express.json());
const port = 4000;

const userRoute = require("./routes/user");
const productRoute = require("./routes/products");

app.get('/', (req, res) => res.send('Hello World!'));

app.use("/users" , userRoute);
app.use("/products" , productRoute);


app.listen(port, () => console.log(`app listening on port 4000!`));


